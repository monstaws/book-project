# telegram_bot.py
"""
Telegram Bot for Price Monitoring with ML-based predictions
"""

import logging
import asyncio
import sqlite3
from datetime import datetime, timedelta
import numpy as np
import pandas as pd
from typing import List, Dict, Optional
import pickle
import joblib

# Telegram bot libraries
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, 
    CommandHandler, 
    MessageHandler, 
    CallbackQueryHandler,
    ContextTypes,
    filters
)

# Machine Learning libraries
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import warnings
warnings.filterwarnings('ignore')

# Import our price watcher
from iranian_price_watcher import PriceWatcher, DatabaseManager, PersianNumberConverter
from config import BOT_TOKEN, ADMIN_IDS, DB_PATH, USE_SELENIUM, CHECK_INTERVAL

# ==================== Configuration ====================

# Logging setup
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# ==================== ML Price Predictor ====================

class PricePredictor:
    """Machine Learning model for price predictions"""
    
    def __init__(self):
        self.model = RandomForestRegressor(
            n_estimators=100,
            max_depth=10,
            random_state=42
        )
        self.scaler = StandardScaler()
        self.is_trained = False
        
    def prepare_features(self, price_history: List[tuple]) -> np.ndarray:
        """Convert price history to ML features"""
        
        if len(price_history) < 3:
            return None
        
        # Extract prices and timestamps
        prices = []
        timestamps = []
        
        for price, timestamp_str, availability in price_history:
            if price is not None:
                prices.append(price)
                # Convert timestamp to numerical value (days from first observation)
                ts = datetime.fromisoformat(timestamp_str.replace(' ', 'T'))
                timestamps.append(ts.timestamp())
        
        if len(prices) < 3:
            return None
        
        # Create features
        features = []
        
        # Price statistics
        features.append(np.mean(prices))  # Average price
        features.append(np.std(prices))   # Price volatility
        features.append(np.min(prices))   # Minimum price
        features.append(np.max(prices))   # Maximum price
        
        # Price trends
        if len(prices) >= 2:
            features.append(prices[-1] - prices[-2])  # Last price change
            features.append((prices[-1] - prices[0]) / max(1, len(prices)))  # Average daily change
        else:
            features.append(0)
            features.append(0)
        
        # Time features
        days_tracked = (timestamps[-1] - timestamps[0]) / 86400  # Days tracked
        features.append(days_tracked)
        
        # Price momentum
        if len(prices) >= 5:
            recent_avg = np.mean(prices[-3:])
            older_avg = np.mean(prices[-6:-3]) if len(prices) >= 6 else np.mean(prices[:-3])
            momentum = (recent_avg - older_avg) / older_avg if older_avg > 0 else 0
            features.append(momentum)
        else:
            features.append(0)
        
        return np.array(features).reshape(1, -1)
    
    def train(self, training_data: List[Dict]):
        """Train the model on historical data"""
        
        X = []
        y = []
        
        for item in training_data:
            features = self.prepare_features(item['history'][:-1])
            if features is not None and item['history']:
                X.append(features[0])
                # Target is the last known price
                last_price = item['history'][-1][0]
                if last_price:
                    y.append(last_price)
        
        if len(X) < 10:  # Need minimum data to train
            return False
        
        X = np.array(X)
        y = np.array(y)
        
        # Split and scale
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42
        )
        
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)
        
        # Train model
        self.model.fit(X_train_scaled, y_train)
        
        # Calculate accuracy
        train_score = self.model.score(X_train_scaled, y_train)
        test_score = self.model.score(X_test_scaled, y_test)
        
        logger.info(f"Model trained - Train R²: {train_score:.3f}, Test R²: {test_score:.3f}")
        
        self.is_trained = True
        return True
    
    def predict_price(self, price_history: List[tuple], days_ahead: int = 7) -> Dict:
        """Predict future price"""
        
        if not self.is_trained:
            return {'error': 'Model not trained yet'}
        
        features = self.prepare_features(price_history)
        if features is None:
            return {'error': 'Not enough data for prediction'}
        
        # Scale features
        features_scaled = self.scaler.transform(features)
        
        # Make prediction
        predicted_price = self.model.predict(features_scaled)[0]
        
        # Get prediction confidence (using feature importances)
        feature_importance = self.model.feature_importances_
        confidence = np.mean(feature_importance) * 100
        
        # Calculate price trend
        current_price = [p for p, _, _ in price_history if p][-1]
        price_change = predicted_price - current_price
        price_change_percent = (price_change / current_price) * 100
        
        return {
            'current_price': int(current_price),
            'predicted_price': int(predicted_price),
            'price_change': int(price_change),
            'price_change_percent': round(price_change_percent, 2),
            'confidence': round(confidence, 2),
            'days_ahead': days_ahead
        }
    
    def find_best_deals(self, all_products: List[Dict]) -> List[Dict]:
        """Find products with best profit potential"""
        
        deals = []
        
        for product in all_products:
            if len(product['history']) < 5:
                continue
            
            prediction = self.predict_price(product['history'])
            if 'error' not in prediction:
                # Calculate deal score
                price_drop_score = -prediction['price_change_percent']  # Higher for price drops
                volatility = np.std([p for p, _, _ in product['history'] if p])
                
                # Combined score (you can adjust weights)
                deal_score = price_drop_score * 0.7 + (volatility / 1000) * 0.3
                
                deals.append({
                    'product': product,
                    'prediction': prediction,
                    'deal_score': deal_score
                })
        
        # Sort by deal score
        deals.sort(key=lambda x: x['deal_score'], reverse=True)
        
        return deals[:10]  # Top 10 deals

# ==================== Telegram Bot Handlers ====================

class TelegramPriceBot:
    """Main Telegram bot class"""
    
    def __init__(self):
        self.watcher = PriceWatcher(use_selenium=USE_SELENIUM)
        self.db = DatabaseManager(DB_PATH)
        self.predictor = PricePredictor()
        self.user_states = {}  # Track user conversation states
    
    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /start command"""
        
        user = update.effective_user
        welcome_text = f"""
👋 سلام {user.first_name}!

🤖 من ربات هوشمند قیمت‌یاب کتاب هستم.

📚 **قابلیت‌های من:**
• نظارت بر قیمت محصولات در دیوار و شیپور
• پیش‌بینی قیمت با هوش مصنوعی
• پیدا کردن بهترین معاملات
• هشدار کاهش قیمت

📝 **دستورات اصلی:**
/track [لینک] - شروع نظارت بر محصول
/list - لیست محصولات در حال نظارت
/predict [لینک] - پیش‌بینی قیمت
/deals - بهترین معاملات
/alert [لینک] [قیمت] - تنظیم هشدار قیمت
/help - راهنمای کامل

🔗 برای شروع، لینک محصول را ارسال کنید!
        """
        
        keyboard = [
            [InlineKeyboardButton("➕ افزودن محصول", callback_data='add_product')],
            [InlineKeyboardButton("📊 لیست محصولات", callback_data='list_products')],
            [InlineKeyboardButton("🎯 بهترین معاملات", callback_data='best_deals')],
            [InlineKeyboardButton("❓ راهنما", callback_data='help')]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            welcome_text,
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
    
    async def track_product(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Track a new product"""
        
        # Extract URL from message
        text = update.message.text
        
        # Find URL in text
        url_pattern = r'https?://[^\s]+'
        import re
        urls = re.findall(url_pattern, text)
        
        if not urls:
            await update.message.reply_text(
                "❌ لطفاً یک لینک معتبر ارسال کنید.\n"
                "مثال: https://divar.ir/v/..."
            )
            return
        
        url = urls[0]
        
        # Check if it's a supported platform
        if 'divar.ir' not in url and 'sheypoor.com' not in url:
            await update.message.reply_text(
                "⚠️ فقط لینک‌های دیوار و شیپور پشتیبانی می‌شوند."
            )
            return
        
        # Send "processing" message
        processing_msg = await update.message.reply_text(
            "🔄 در حال بررسی محصول..."
        )
        
        # Track the product
        result = self.watcher.watch_product(url)
        
        # Delete processing message
        await processing_msg.delete()
        
        if 'error' in result:
            await update.message.reply_text(
                f"❌ خطا: {result['error']}"
            )
        else:
            response = f"""
✅ **محصول با موفقیت اضافه شد!**

📌 **عنوان:** {result['title'] or 'نامشخص'}
💰 **قیمت فعلی:** {f"{result['price']:,} تومان" if result['price'] else "قیمت یافت نشد"}
🏪 **پلتفرم:** {result['platform']}
🔗 **لینک:** {url}

برای پیش‌بینی قیمت از دستور زیر استفاده کنید:
/predict {url}
            """
            
            await update.message.reply_text(
                response,
                parse_mode='Markdown',
                disable_web_page_preview=True
            )
    
    async def predict(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Predict future price"""
        
        if not context.args:
            await update.message.reply_text(
                "❌ لطفاً لینک محصول را وارد کنید.\n"
                "مثال: /predict https://divar.ir/v/..."
            )
            return
        
        url = context.args[0]
        
        # Get product from database
        conn = sqlite3.connect(self.db.db_path)
        cursor = conn.cursor()
        cursor.execute('SELECT id FROM products WHERE url = ?', (url,))
        result = cursor.fetchone()
        
        if not result:
            await update.message.reply_text(
                "⚠️ این محصول هنوز ثبت نشده است.\n"
                "ابتدا با دستور /track آن را اضافه کنید."
            )
            conn.close()
            return
        
        product_id = result[0]
        
        # Get price history
        history = self.db.get_price_history(product_id, days=30)
        
        if len(history) < 5:
            await update.message.reply_text(
                "📊 داده کافی برای پیش‌بینی وجود ندارد.\n"
                "حداقل 5 بار قیمت‌گیری نیاز است."
            )
            conn.close()
            return
        
        # Make prediction
        prediction = self.predictor.predict_price(history)
        
        if 'error' in prediction:
            await update.message.reply_text(
                f"❌ خطا در پیش‌بینی: {prediction['error']}"
            )
        else:
            trend_emoji = "📈" if prediction['price_change'] > 0 else "📉"
            
            response = f"""
🔮 **پیش‌بینی قیمت (7 روز آینده)**

💰 **قیمت فعلی:** {prediction['current_price']:,} تومان
🎯 **قیمت پیش‌بینی شده:** {prediction['predicted_price']:,} تومان
{trend_emoji} **تغییر قیمت:** {prediction['price_change']:,} تومان ({prediction['price_change_percent']:+.1f}%)
📊 **اطمینان مدل:** {prediction['confidence']:.1f}%

💡 **توصیه:**
"""
            
            if prediction['price_change_percent'] < -10:
                response += "صبر کنید - احتمال کاهش قیمت بیشتر"
            elif prediction['price_change_percent'] > 10:
                response += "اگر نیاز دارید، الان بخرید - قیمت در حال افزایش"
            else:
                response += "قیمت نسبتاً ثابت - تصمیم بر اساس نیاز شما"
            
            await update.message.reply_text(
                response,
                parse_mode='Markdown'
            )
        
        conn.close()
    
    async def list_products(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """List all tracked products"""
        
        conn = sqlite3.connect(self.db.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT p.id, p.url, p.title, p.platform, 
                   (SELECT price FROM price_history 
                    WHERE product_id = p.id 
                    ORDER BY timestamp DESC LIMIT 1) as last_price,
                   p.last_checked
            FROM products p
            ORDER BY p.last_checked DESC
            LIMIT 20
        ''')
        
        products = cursor.fetchall()
        conn.close()
        
        if not products:
            await update.message.reply_text(
                "📋 هیچ محصولی در حال نظارت نیست.\n"
                "با /track یک محصول اضافه کنید."
            )
            return
        
        response = "📋 **محصولات در حال نظارت:**\n\n"
        
        for i, (pid, url, title, platform, price, last_checked) in enumerate(products, 1):
            response += f"{i}. **{title or 'بدون عنوان'}**\n"
            response += f"   💰 {f'{price:,} تومان' if price else 'قیمت نامشخص'}\n"
            response += f"   🏪 {platform}\n"
            response += f"   🕐 {last_checked[:16] if last_checked else 'بررسی نشده'}\n\n"
        
        await update.message.reply_text(
            response,
            parse_mode='Markdown',
            disable_web_page_preview=True
        )
    
    async def find_deals(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Find best deals using ML"""
        
        await update.message.reply_text("🔍 در حال جستجوی بهترین معاملات...")
        
        # Get all products with sufficient history
        conn = sqlite3.connect(self.db.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT p.id, p.url, p.title, p.platform
            FROM products p
            WHERE (SELECT COUNT(*) FROM price_history WHERE product_id = p.id) >= 5
        ''')
        
        products = cursor.fetchall()
        
        if not products:
            await update.message.reply_text(
                "📊 داده کافی برای تحلیل وجود ندارد.\n"
                "لطفاً محصولات بیشتری را نظارت کنید."
            )
            conn.close()
            return
        
        # Prepare data for ML
        all_products_data = []
        for pid, url, title, platform in products:
            history = self.db.get_price_history(pid)
            all_products_data.append({
                'id': pid,
                'url': url,
                'title': title,
                'platform': platform,
                'history': history
            })
        
        # Find best deals
        deals = self.predictor.find_best_deals(all_products_data)
        
        if not deals:
            await update.message.reply_text(
                "❌ معامله خوبی پیدا نشد.\n"
                "بعداً دوباره امتحان کنید."
            )
            conn.close()
            return
        
        response = "🎯 **بهترین معاملات:**\n\n"
        
        for i, deal in enumerate(deals[:5], 1):
            product = deal['product']
            prediction = deal['prediction']
            
            emoji = "🔥" if deal['deal_score'] > 50 else "✨"
            
            response += f"{emoji} **{i}. {product['title'] or 'محصول'}**\n"
            response += f"   💰 قیمت فعلی: {prediction['current_price']:,} تومان\n"
            response += f"   🎯 پیش‌بینی: {prediction['predicted_price']:,} تومان\n"
            response += f"   📊 تغییر: {prediction['price_change_percent']:+.1f}%\n"
            response += f"   🏪 {product['platform']}\n"
            response += f"   🔗 [مشاهده]({product['url']})\n\n"
        
        await update.message.reply_text(
            response,
            parse_mode='Markdown',
            disable_web_page_preview=True
        )
        
        conn.close()
    
    async def set_alert(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Set price alert"""
        
        if len(context.args) < 2:
            await update.message.reply_text(
                "❌ استفاده: /alert [لینک] [قیمت هدف]\n"
                "مثال: /alert https://divar.ir/v/... 500000"
            )
            return
        
        url = context.args[0]
        try:
            target_price = int(context.args[1])
        except ValueError:
            await update.message.reply_text("❌ قیمت باید عدد باشد")
            return
        
        # Add alert to database
        conn = sqlite3.connect(self.db.db_path)
        cursor = conn.cursor()
        
        # Get product ID
        cursor.execute('SELECT id FROM products WHERE url = ?', (url,))
        result = cursor.fetchone()
        
        if not result:
            # Track product first
            product_result = self.watcher.watch_product(url)
            if 'error' in product_result:
                await update.message.reply_text(f"❌ خطا: {product_result['error']}")
                conn.close()
                return
            
            cursor.execute('SELECT id FROM products WHERE url = ?', (url,))
            result = cursor.fetchone()
        
        product_id = result[0]
        
        # Add alert
        cursor.execute('''
            INSERT INTO alerts (product_id, target_price, alert_type)
            VALUES (?, ?, 'price_drop')
            ON CONFLICT(product_id) DO UPDATE SET target_price=excluded.target_price
        ''', (product_id, target_price))
        
        conn.commit()
        conn.close()
        
        await update.message.reply_text(
            f"✅ هشدار تنظیم شد!\n"
            f"وقتی قیمت به {target_price:,} تومان برسد، اطلاع می‌دهم."
        )
    
    async def scan_page(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """
        Scan a page, get all book prices, and add them to database for tracking.
        This command scans and automatically starts monitoring all found products.
        """
        import re
        text = " ".join(context.args) if context.args else (update.message.text or "")
        url_match = re.search(r'https?://[^\s]+', text)
        if not url_match:
            await update.message.reply_text(
                "❌ لطفاً لینک صفحه‌ای که می‌خواهید اسکن کنید را ارسال کنید.\n"
                "مثال: /scan_page https://divar.ir/s/iran?q=کتاب"
            )
            return
        
        url = url_match.group(0)
        
        # Send processing message
        processing_msg = await update.message.reply_text("🔍 در حال اسکن صفحه و افزودن محصولات به دیتابیس...")
        
        watcher = PriceWatcher(use_selenium=False)
        try:
            # Extract product links from the page
            product_links = watcher.extract_listing_links(url, limit=20, paginate=False)
            
            # Filter only valid product pages
            valid_links = []
            for link in product_links:
                if link == url:
                    continue
                if ("divar.ir" in link and "/v/" in link) or ("sheypoor.com" in link and ("/ad" in link or "/post" in link)):
                    valid_links.append(link)
            
            if not valid_links:
                await processing_msg.edit_text("❌ هیچ محصولی در این صفحه پیدا نشد.")
                return
            
            # Track all products and store in database
            products_data = []
            added_count = 0
            updated_count = 0
            
            for idx, link in enumerate(valid_links[:15], 1):  # Limit to 15 products to avoid timeout
                try:
                    # Update progress message
                    await processing_msg.edit_text(f"🔍 در حال پردازش محصول {idx}/{min(15, len(valid_links))}...")
                    
                    # Use the existing watch_product method to track and store
                    result = watcher.watch_product(link)
                    
                    if 'error' not in result and result.get('title'):
                        products_data.append(result)
                        if result.get('price'):
                            added_count += 1
                        else:
                            updated_count += 1
                            
                except Exception as e:
                    logger.warning(f"Error scanning product {link}: {e}")
                    continue
            
            # Delete processing message
            await processing_msg.delete()
            
            if not products_data:
                await update.message.reply_text("❌ نتوانستم هیچ محصولی را پردازش کنم.")
                return
            
            # Create summary message
            total_products = len(products_data)
            products_with_price = [p for p in products_data if p.get('price')]
            
            if products_with_price:
                prices = [p['price'] for p in products_with_price]
                avg_price = sum(prices) / len(prices)
                min_price = min(prices)
                max_price = max(prices)
                
                summary = f"✅ **صفحه اسکن شد و محصولات اضافه شدند!**\n\n"
                summary += f"📊 **خلاصه:**\n"
                summary += f"🔢 تعداد کل محصولات: {total_products}\n"
                summary += f"💰 محصولات با قیمت: {len(products_with_price)}\n"
                summary += f"📈 میانگین قیمت: {avg_price:,.0f} تومان\n"
                summary += f"📉 کمترین قیمت: {min_price:,} تومان\n"
                summary += f"📊 بیشترین قیمت: {max_price:,} تومان\n\n"
            else:
                summary = f"✅ **صفحه اسکن شد!**\n\n"
                summary += f"📊 **خلاصه:**\n"
                summary += f"🔢 تعداد کل محصولات: {total_products}\n"
                summary += f"⚠️ هیچ قیمتی یافت نشد\n\n"
            
            # Add detailed list
            summary += "📚 **محصولات اضافه شده:**\n"
            for idx, product in enumerate(products_data[:10], 1):  # Show first 10
                price_text = f"{product['price']:,} تومان" if product.get('price') else "قیمت نامشخص"
                summary += f"\n{idx}. **{product['title'][:50]}{'...' if len(product['title']) > 50 else ''}**\n"
                summary += f"   💰 {price_text}\n"
                summary += f"   🏪 {product.get('platform', 'نامشخص')}\n"
                summary += f"   🔗 [مشاهده]({product['url']})\n"
            
            if len(products_data) > 10:
                summary += f"\n... و {len(products_data) - 10} محصول دیگر"
            
            summary += f"\n\n🔔 **همه محصولات اکنون تحت نظارت هستند!**\n"
            summary += f"برای مشاهده لیست کامل از دستور /list استفاده کنید."
            
            await update.message.reply_text(
                summary,
                parse_mode='Markdown',
                disable_web_page_preview=True
            )
            
        except Exception as e:
            await processing_msg.edit_text(f"❌ خطا در اسکن صفحه: {str(e)}")
            logger.error(f"Error in scan_page: {e}")
        finally:
            watcher.cleanup()

    async def help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show help message"""
        
        help_text = """
📚 **راهنمای کامل ربات قیمت‌یاب**

**دستورات اصلی:**
• /start - شروع کار با ربات
• /track [لینک] - نظارت بر محصول جدید
• /scan_page [لینک] - اسکن صفحه و افزودن همه محصولات
• /list - نمایش لیست محصولات
• /predict [لینک] - پیش‌بینی قیمت با AI
• /deals - یافتن بهترین معاملات
• /alert [لینک] [قیمت] - تنظیم هشدار قیمت
• /stats - آمار کلی
• /help - این پیام

**نحوه استفاده:**
1️⃣ لینک محصول را از دیوار یا شیپور کپی کنید
2️⃣ با دستور /track آن را اضافه کنید
3️⃣ ربات به طور خودکار قیمت را چک می‌کند
4️⃣ با /predict آینده قیمت را پیش‌بینی کنید
5️⃣ با /alert هشدار قیمت تنظیم کنید
6️⃣ با /scan_page صفحه جستجو را اسکن و همه محصولات را اضافه کنید

**نکات:**
• ربات هر 30 دقیقه قیمت‌ها را چک می‌کند
• برای پیش‌بینی دقیق، حداقل 5 بار قیمت‌گیری نیاز است
• دستور /scan_page همه محصولات را به دیتابیس اضافه می‌کند
• با /scan_page می‌توانید تا 15 محصول را یکجا اضافه کنید
• می‌توانید تا 50 محصول را همزمان نظارت کنید

💡 **برای کسب درآمد:**
• محصولات با قیمت پایین‌تر از میانگین را پیدا کنید
• با /predict روند قیمت را بررسی کنید
• در زمان مناسب خرید و فروش کنید

🔗 @YourUsername برای پشتیبانی
        """
        
        await update.message.reply_text(
            help_text,
            parse_mode='Markdown'
        )
    
    async def handle_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle inline keyboard callbacks"""
        
        query = update.callback_query
        await query.answer()
        
        if query.data == 'add_product':
            await query.edit_message_text(
                "🔗 لطفاً لینک محصول را ارسال کنید:\n"
                "(از دیوار یا شیپور)"
            )
        elif query.data == 'list_products':
            await self.list_products(query, context)
        elif query.data == 'best_deals':
            await self.find_deals(query, context)
        elif query.data == 'help':
            await self.help_command(query, context)

# ==================== Main Bot Runner ====================

async def check_price_alerts(context: ContextTypes.DEFAULT_TYPE):
    """Periodic task to check price alerts"""
    
    db = DatabaseManager()
    watcher = PriceWatcher(use_selenium=False)  # Use requests for periodic checks
    
    conn = sqlite3.connect(db.db_path)
    cursor = conn.cursor()
    
    # Get active alerts
    cursor.execute('''
        SELECT a.id, a.product_id, a.target_price, p.url, p.title
        FROM alerts a
        JOIN products p ON a.product_id = p.id
        WHERE a.is_active = 1
    ''')
    
    alerts = cursor.fetchall()
    
    for alert_id, product_id, target_price, url, title in alerts:
        # Check current price
        result = watcher.watch_product(url)
        
        if result and result.get('price'):
            current_price = result['price']
            
            if current_price <= target_price:
                # Send alert to all users (you'd need to track user IDs)
                message = f"""
🚨 **هشدار قیمت!**

📌 {title or 'محصول'}
💰 قیمت فعلی: {current_price:,} تومان
🎯 قیمت هدف: {target_price:,} تومان
✅ قیمت به هدف رسید!

🔗 {url}
                """
                
                # Send to admin (replace with actual user tracking)
                for admin_id in ADMIN_IDS:
                    try:
                        await context.bot.send_message(
                            chat_id=admin_id,
                            text=message,
                            parse_mode='Markdown'
                        )
                    except Exception as e:
                        logger.error(f"Failed to send alert: {e}")
                
                # Deactivate alert
                cursor.execute(
                    'UPDATE alerts SET is_active = 0 WHERE id = ?',
                    (alert_id,)
                )
                conn.commit()
    
    conn.close()
    watcher.cleanup()

async def post_init(application):
    """Schedule periodic tasks after bot starts"""
    if application.job_queue is not None:
        application.job_queue.run_repeating(check_price_alerts, interval=1800, first=10)
        logger.info("Job queue started successfully")
    else:
        logger.error("Job queue is not available")

def main():
    """Main function to run the bot"""
    
    # Create application with job queue enabled
    from telegram.ext import JobQueue
    application = Application.builder().token(BOT_TOKEN).job_queue(JobQueue()).build()
    
    # Initialize bot instance
    bot = TelegramPriceBot()
    
    # Add handlers
    application.add_handler(CommandHandler("start", bot.start))
    application.add_handler(CommandHandler("track", bot.track_product))
    application.add_handler(CommandHandler("scan_page", bot.scan_page))
    application.add_handler(CommandHandler("predict", bot.predict))
    application.add_handler(CommandHandler("list", bot.list_products))
    application.add_handler(CommandHandler("deals", bot.find_deals))
    application.add_handler(CommandHandler("alert", bot.set_alert))
    application.add_handler(CommandHandler("help", bot.help_command))
    
    # Handle plain text messages (URLs)
    application.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND, 
        bot.track_product
    ))
    
    # Handle callback queries
    application.add_handler(CallbackQueryHandler(bot.handle_callback))
    
    application.post_init = post_init

    # Start the bot
    logger.info("Bot is starting...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()