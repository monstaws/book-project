# config.py
import os

# Bot configuration - read from environment variables for Azure deployment
BOT_TOKEN = os.getenv("BOT_TOKEN", "8238088046:AAHZlL4WPcdoIVVxIw0E0K_cS-0OYMEm4Uk")
ADMIN_IDS = [int(x) for x in os.getenv("ADMIN_IDS", "247458062").split(",")]

# Database settings
DB_PATH = os.getenv("DB_PATH", "price_tracker.db")

# Scraping settings
USE_SELENIUM = os.getenv("USE_SELENIUM", "false").lower() == "true"
CHECK_INTERVAL = int(os.getenv("CHECK_INTERVAL", "1800"))  # 30 minutes