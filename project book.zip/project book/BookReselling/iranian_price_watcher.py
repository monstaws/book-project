# enhanced_price_watcher.py
"""
Multi-platform price watcher for Iranian e-commerce sites
Supports: Divar, Sheypoor, and expandable to other platforms
"""

import requests
from bs4 import BeautifulSoup
import re
import time
import json
from datetime import datetime
from typing import Optional, Dict, List, Tuple
import sqlite3
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
import logging
from urllib.parse import urljoin, urlparse

# ==================== Configuration ====================
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

class PersianNumberConverter:
    """Handle Persian/Arabic number conversions"""

    PERSIAN_DIGITS = "۰۱۲۳۴۵۶۷۸۹"
    ARABIC_DIGITS = "٠١٢٣٤٥٦٧٨٩"
    LATIN_DIGITS = "0123456789"
    
    @classmethod
    def to_latin(cls, text: str) -> str:
        """Convert Persian and Arabic digits to Latin"""
        if not text:
            return text
        
        # Create translation table
        persian_trans = str.maketrans(cls.PERSIAN_DIGITS, cls.LATIN_DIGITS)
        arabic_trans = str.maketrans(cls.ARABIC_DIGITS, cls.LATIN_DIGITS)
        
        # Apply both translations
        text = text.translate(persian_trans)
        text = text.translate(arabic_trans)
        
        return text
    
    @classmethod
    def extract_price(cls, text: str) -> Optional[int]:
        """Extract price from text containing Persian/Arabic numerals"""
        if not text:
            return None
        
        # Convert to Latin digits
        text = cls.to_latin(text)
        
        # Remove common separators and extract numbers
        # Pattern for prices with تومان or ریال
        patterns = [
            r'([\d,،]+)\s*(?:تومان|ریال)',  # With currency
            r'قیمت[:\s]*([\d,،]+)',           # After "price"
            r'([\d]{1,3}(?:[,،]\d{3})+)',     # Formatted numbers
            r'([\d]{4,})'                     # Any long number
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                price_str = match.group(1)
                # Remove separators
                price_str = re.sub(r'[,،\s]', '', price_str)
                try:
                    price = int(price_str)
                    # Convert rial to toman if needed (rial prices are typically > 1,000,000)
                    if price > 10000000:
                        price = price // 10
                    return price
                except ValueError:
                    continue
        
        return None

class DatabaseManager:
    """Manage SQLite database for price tracking"""
    
    def __init__(self, db_path: str = "price_tracker.db"):
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Create necessary tables"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Products table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                url TEXT UNIQUE NOT NULL,
                title TEXT,
                platform TEXT NOT NULL,
                category TEXT,
                first_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_checked TIMESTAMP
            )
        ''')
        
        # Price history table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS price_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id INTEGER NOT NULL,
                price INTEGER,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                availability TEXT,
                FOREIGN KEY (product_id) REFERENCES products(id)
            )
        ''')
        
        # Alerts table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS alerts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id INTEGER NOT NULL,
                target_price INTEGER,
                alert_type TEXT,
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (product_id) REFERENCES products(id)
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def add_product(self, url: str, platform: str, title: str = None, category: str = None) -> int:
        """Add a product to track"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                INSERT INTO products (url, title, platform, category, last_checked)
                VALUES (?, ?, ?, ?, ?)
            ''', (url, title, platform, category, datetime.now()))
            product_id = cursor.lastrowid
        except sqlite3.IntegrityError:
            # Product already exists, get its ID
            cursor.execute('SELECT id FROM products WHERE url = ?', (url,))
            product_id = cursor.fetchone()[0]
        
        conn.commit()
        conn.close()
        return product_id
    
    def add_price_record(self, product_id: int, price: Optional[int], availability: str = "available"):
        """Record a price observation"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO price_history (product_id, price, availability)
            VALUES (?, ?, ?)
        ''', (product_id, price, availability))
        
        # Update last_checked
        cursor.execute('''
            UPDATE products SET last_checked = ? WHERE id = ?
        ''', (datetime.now(), product_id))
        
        conn.commit()
        conn.close()
    
    def get_price_history(self, product_id: int, days: int = 30) -> List[Tuple]:
        """Get price history for a product"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT price, timestamp, availability
            FROM price_history
            WHERE product_id = ? 
            AND timestamp > datetime('now', '-{} days')
            ORDER BY timestamp DESC
        '''.format(days), (product_id,))
        
        results = cursor.fetchall()
        conn.close()
        return results

class BaseScraper:
    """Base scraper class with common functionality"""
    
    def __init__(self, use_selenium: bool = True):
        self.use_selenium = use_selenium
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept-Language': 'fa-IR,fa;q=0.9,en;q=0.8',
        }
        self.driver = None
        
        if use_selenium:
            self.setup_selenium()
    
    def setup_selenium(self):
        """Setup Selenium WebDriver"""
        options = Options()
        options.add_argument('--headless')  # Run in background
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        options.add_argument('--disable-blink-features=AutomationControlled')
        options.add_experimental_option("excludeSwitches", ["enable-automation"])
        options.add_experimental_option('useAutomationExtension', False)
        
        try:
            self.driver = webdriver.Chrome(options=options)
        except Exception as e:
            logging.error(f"Failed to setup Selenium: {e}")
            self.use_selenium = False
    
    def get_page_content(self, url: str) -> Optional[str]:
        """Get page content using Selenium or requests"""
        if self.use_selenium and self.driver:
            try:
                self.driver.get(url)
                time.sleep(3)  # Wait for dynamic content
                return self.driver.page_source
            except Exception as e:
                logging.error(f"Selenium error: {e}")
                return None
        else:
            try:
                response = requests.get(url, headers=self.headers, timeout=15)
                if response.status_code == 200:
                    return response.text
                return None
            except Exception as e:
                logging.error(f"Request error: {e}")
                return None
    
    def extract_price(self, html: str) -> Optional[int]:
        """Override in subclasses"""
        raise NotImplementedError
    
    def extract_title(self, html: str) -> Optional[str]:
        """Override in subclasses"""
        raise NotImplementedError
    
    def close(self):
        """Cleanup resources"""
        if self.driver:
            self.driver.quit()

class DivarScraper(BaseScraper):
    """Scraper specifically for Divar.ir"""
    
    PRICE_SELECTORS = [
        'p.kt-unexpandable-row__value',
        'div[class*="price"]',
        'span[class*="price"]',
        '.post-fields-item__value',
        '.kt-base-row__end'
    ]
    
    def extract_price(self, html: str) -> Optional[int]:
        """Extract price from Divar page"""
        soup = BeautifulSoup(html, 'html.parser')
        
        # Try specific selectors
        for selector in self.PRICE_SELECTORS:
            elements = soup.select(selector)
            for elem in elements:
                text = elem.get_text(strip=True)
                price = PersianNumberConverter.extract_price(text)
                if price:
                    return price
        
        # Try to find in JSON-LD structured data
        scripts = soup.find_all('script', type='application/ld+json')
        for script in scripts:
            try:
                data = json.loads(script.string)
                if 'price' in str(data).lower():
                    price_text = json.dumps(data, ensure_ascii=False)
                    price = PersianNumberConverter.extract_price(price_text)
                    if price:
                        return price
            except:
                continue
        
        # Last resort: search entire page
        full_text = soup.get_text()
        return PersianNumberConverter.extract_price(full_text)
    
    def extract_title(self, html: str) -> Optional[str]:
        """Extract product title from Divar page"""
        soup = BeautifulSoup(html, 'html.parser')
        
        # Try common title selectors
        title_selectors = ['h1', '.kt-page-title__title', '[class*="title"]']
        for selector in title_selectors:
            elem = soup.select_one(selector)
            if elem:
                return elem.get_text(strip=True)
        
        return None

class SheypoorScraper(BaseScraper):
    """Scraper specifically for Sheypoor.com"""
    
    PRICE_SELECTORS = [
        'p[class*="price"]',
        'span[class*="price"]',
        'div[class*="price"]',
        '.price-tag',
        '[data-testid="price"]'
    ]
    
    def extract_price(self, html: str) -> Optional[int]:
        """Extract price from Sheypoor page"""
        soup = BeautifulSoup(html, 'html.parser')
        
        # Try specific selectors
        for selector in self.PRICE_SELECTORS:
            elements = soup.select(selector)
            for elem in elements:
                text = elem.get_text(strip=True)
                price = PersianNumberConverter.extract_price(text)
                if price:
                    return price
        
        # Search in meta tags
        meta_price = soup.find('meta', {'property': 'product:price:amount'})
        if meta_price and meta_price.get('content'):
            try:
                return int(meta_price['content'])
            except:
                pass
        
        # Last resort: search entire page
        full_text = soup.get_text()
        return PersianNumberConverter.extract_price(full_text)
    
    def extract_title(self, html: str) -> Optional[str]:
        """Extract product title from Sheypoor page"""
        soup = BeautifulSoup(html, 'html.parser')
        
        # Try common title selectors
        title_selectors = ['h1', '[class*="title"]', 'meta[property="og:title"]']
        for selector in title_selectors:
            if selector.startswith('meta'):
                elem = soup.select_one(selector)
                if elem:
                    return elem.get('content', '').strip()
            else:
                elem = soup.select_one(selector)
                if elem:
                    return elem.get_text(strip=True)
        
        return None

class PriceWatcher:
    """Main orchestrator for price watching"""
    
    def __init__(self, use_selenium: bool = True):
        self.db = DatabaseManager()
        self.scrapers = {
            'divar': DivarScraper(use_selenium),
            'sheypoor': SheypoorScraper(use_selenium)
        }
    
    def identify_platform(self, url: str) -> Optional[str]:
        """Identify which platform the URL belongs to"""
        if 'divar.ir' in url:
            return 'divar'
        elif 'sheypoor.com' in url:
            return 'sheypoor'
        else:
            return None
    
    def watch_product(self, url: str) -> Dict:
        """Watch a single product"""
        platform = self.identify_platform(url)
        if not platform:
            return {'error': 'Unsupported platform'}
        
        scraper = self.scrapers.get(platform)
        if not scraper:
            return {'error': 'No scraper available for platform'}
        
        # Get page content
        html = scraper.get_page_content(url)
        if not html:
            return {'error': 'Failed to fetch page'}
        
        # Extract data
        price = scraper.extract_price(html)
        title = scraper.extract_title(html)
        
        # Store in database
        product_id = self.db.add_product(url, platform, title)
        self.db.add_price_record(
            product_id, 
            price, 
            'available' if price else 'price_not_found'
        )
        
        result = {
            'platform': platform,
            'url': url,
            'title': title,
            'price': price,
            'timestamp': datetime.now().isoformat()
        }
        
        logging.info(f"Watched: {title} - Price: {price}")
        
        return result
    
    def extract_listing_links(self, listing_url: str, limit: int = 50, paginate: bool = False, max_pages: int = 3) -> List[str]:
        """
        Parse a listing page and return product URLs (domain-specific heuristics).
        - listing_url: page containing many product cards (category / search / user page)
        - limit: max number of product links to return
        - paginate: if True, try to follow "next" links up to max_pages
        """
        results = []
        seen = set()
        to_visit = [listing_url]
        pages_visited = 0

        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept-Language': 'fa-IR,fa;q=0.9,en;q=0.8',
        }

        while to_visit and len(results) < limit and pages_visited < max_pages:
            url = to_visit.pop(0)
            pages_visited += 1

            # Prefer using requests for listing pages (lighter than Selenium)
            try:
                import requests
                resp = requests.get(url, headers=headers, timeout=15)
                if resp.status_code != 200:
                    continue
                html = resp.text
            except Exception as e:
                logging.warning(f"Failed to fetch listing page {url}: {e}")
                continue

            soup = BeautifulSoup(html, 'html.parser')

            parsed = urlparse(url)
            base = f"{parsed.scheme}://{parsed.netloc}"

            # General approach: find anchor tags whose href looks like a product page
            for a in soup.find_all('a', href=True):
                href = a['href'].strip()
                # Make absolute
                full = urljoin(base, href)

                # Heuristics: divar uses '/v/' for item pages; sheypoor uses '/ad' or '/post'
                if parsed.netloc.endswith('divar.ir') and '/v/' in full:
                    if full not in seen:
                        seen.add(full)
                        results.append(full)
                elif 'sheypoor' in parsed.netloc and ('/ad' in full or '/post' in full or '/posts' in full):
                    if full not in seen:
                        seen.add(full)
                        results.append(full)
                else:
                    # generic: pick links that have '/v/' or look long enough and contain domain
                    if '/v/' in full or re.search(r'/\w{6,}/[A-Za-z0-9\-]+', full):
                        if full not in seen:
                            seen.add(full)
                            results.append(full)

                if len(results) >= limit:
                    break

            # Pagination: try to find "next" link (site dependent, fragile but helpful)
            if paginate and len(results) < limit:
                next_link = None
                # common patterns
                next_link = soup.select_one('a[rel="next"]') or soup.select_one('a.next') or soup.find(string=re.compile("بعدی|next", re.I))
                if isinstance(next_link, str):
                    # if we matched text node 'بعدی', try to find parent anchor
                    anchor = soup.find('a', string=next_link)
                    if anchor and anchor.get('href'):
                        nl = urljoin(base, anchor['href'])
                        to_visit.append(nl)
                elif next_link and getattr(next_link, 'get', None):
                    href = next_link.get('href')
                    if href:
                        to_visit.append(urljoin(base, href))

            # polite delay
            time.sleep(1.0)

        return results[:limit]

    def watch_multiple(self, urls: List[str]) -> List[Dict]:
        """Watch multiple products"""
        results = []
        for url in urls:
            result = self.watch_product(url)
            results.append(result)
            time.sleep(2)  # Be respectful to servers
        
        return results
    
    def get_price_changes(self, product_id: int) -> Dict:
        """Analyze price changes for a product"""
        history = self.db.get_price_history(product_id)
        
        if len(history) < 2:
            return {'message': 'Not enough data for analysis'}
        
        prices = [h[0] for h in history if h[0] is not None]
        
        if not prices:
            return {'message': 'No price data available'}
        
        current_price = prices[0]
        avg_price = sum(prices) / len(prices)
        min_price = min(prices)
        max_price = max(prices)
        
        # Calculate trend
        if len(prices) >= 3:
            recent_avg = sum(prices[:3]) / 3
            older_avg = sum(prices[3:6]) / min(3, len(prices[3:6])) if len(prices) > 3 else recent_avg
            
            if recent_avg < older_avg * 0.95:
                trend = "decreasing"
            elif recent_avg > older_avg * 1.05:
                trend = "increasing"
            else:
                trend = "stable"
        else:
            trend = "insufficient_data"
        
        return {
            'current_price': current_price,
            'average_price': avg_price,
            'min_price': min_price,
            'max_price': max_price,
            'trend': trend,
            'total_observations': len(history)
        }
    
    def cleanup(self):
        """Clean up resources"""
        for scraper in self.scrapers.values():
            scraper.close()

# ==================== Main Execution ====================

def main():
    """Main function for testing"""
    
    # Example URLs
    test_urls = [
        "https://divar.ir/v/شیائومی-واچ-s1/AameDaKa",  # Your original URL
        # Add more URLs here
    ]
    
    # Initialize watcher
    watcher = PriceWatcher(use_selenium=True)  # Set to False if Selenium not installed
    
    try:
        # Watch products
        for url in test_urls:
            print(f"\n{'='*50}")
            print(f"Checking: {url}")
            result = watcher.watch_product(url)
            
            if 'error' in result:
                print(f"Error: {result['error']}")
            else:
                print(f"Title: {result['title']}")
                print(f"Platform: {result['platform']}")
                print(f"Price: {result['price']} تومان" if result['price'] else "Price: Not found")
                print(f"Timestamp: {result['timestamp']}")
        
        print(f"\n{'='*50}")
        print("Price watching completed!")
        
    finally:
        watcher.cleanup()

if __name__ == "__main__":
    main()